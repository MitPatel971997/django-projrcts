from django.apps import AppConfig


class PasswordResetConfig(AppConfig):
    name = 'Password_Reset'
