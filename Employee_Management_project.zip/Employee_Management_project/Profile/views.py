from django.shortcuts import render
from .models import UserProfile
from .serializers import UserProfileSerializer
from .permissions import UpdateOwnProfile
from rest_framework.authentication import TokenAuthentication
from rest_framework import viewsets,status
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView

# Create your views here.

class UserProfileViewSet(viewsets.ModelViewSet):
    """
    creating and updating profile of EMPLOYEE
    """
    serializer_class=UserProfileSerializer
    queryset=UserProfile.objects.all()
    permission_classes=(UpdateOwnProfile,)
