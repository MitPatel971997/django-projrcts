from django.db import models
from Authentication.models import UserRole
from django.db.models.signals import post_save
from django.contrib.auth.models import User
from django.dispatch import receiver

# Create your models here.

class UserProfile(models.Model):

    GENDER_CHOICES = (
        ('MALE', 'MALE'),
        ('FEMALE', 'FEMALE'),
    )
    #USER_ROLE = (
    #    ('EMPLOYEE', 'Employee'),
    #)

    user = models.OneToOneField(User, unique=True,on_delete=models.CASCADE,related_name="user_profile")
    birth_date = models.DateField(null=True)
    gender = models.CharField(max_length=6, choices=GENDER_CHOICES,null=True)
    address = models.TextField(max_length=150,null=True)
    #role = models.CharField(max_length=15, choices=USER_ROLE,null=True)
    profile_pic=models.ImageField(upload_to='profile_pic',null=True)

def create_user_profile(sender, instance, created, **kwargs):
    if created :
        UserProfile.objects.create(user=instance)
    else:
        print("Not Created")

post_save.connect(create_user_profile, sender=User)
