from rest_framework import serializers
from .models import UserProfile
from rest_framework import exceptions

class UserProfileSerializer(serializers.ModelSerializer):
    """
    A serializer for create user profile.
    """
    class Meta:
        model=UserProfile
        fields=('id','birth_date','gender','address','profile_pic')

    def create(self,validated_data):
        user = None
        request = self.context.get("request")
        if request and hasattr(request, "user"):
            user = request.user
            if user.user_role_name.user_role=="EMPLOYEE":
                profile, created = UserProfile.objects.update_or_create(user=user,birth_date=validated_data["birth_date"],gender=validated_data["gender"],
                                                                        address=validated_data["address"],profile_pic=validated_data["profile_pic"])
                return profile
            else:
                raise exceptions.ValidationError("You are not Unable to create profile")
        else:
            raise exceptions.ValidationError("Anonyms Request Found")
