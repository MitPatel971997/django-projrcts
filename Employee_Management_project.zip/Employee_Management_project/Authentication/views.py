from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .serializers import RoleSerializer,LoginSerializer
from django.contrib.auth.models import User
from django.contrib.auth import login as django_login, logout as django_logout
from rest_framework.authtoken.models import Token
from rest_framework.authentication import TokenAuthentication,SessionAuthentication
from rest_framework import permissions

class LoginView(APIView):
    """
    Login User.
    """

    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data["user"]
        django_login(request, user)
        token, created = Token.objects.get_or_create(user=user)
        return Response({"token": token.key}, status=200)

class LogoutView(APIView):
    """
    Logout User.
    """
    authentication_classes = (TokenAuthentication,SessionAuthentication, )

    def get(self, request):
        request.user.auth_token.delete()
        django_logout(request)
        return Response({"detail":"Successfully Logout!!!"},status=status.HTTP_201_CREATED)

class UserCreate(APIView):
    """
    Creates the user.
    """

    def post(self, request, format='json'):
        serializer = RoleSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            if user:
                return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
