from django.db import models
from django.contrib.auth.models import User

class UserRole(models.Model):

    USER_ROLES = (
        ('EMPLOYEE', 'EMPLOYEE'),
        ('VISITOR','VISITOR'),
    )

    user=models.OneToOneField(User,on_delete=models.CASCADE,related_name='user_role_name')
    user_role = models.CharField(max_length=15, choices=USER_ROLES,default='VISITOR',null=True)



# Create your models here.
