from rest_framework import serializers
from .models import UserRole
from django.contrib.auth.models import User
from rest_framework.validators import UniqueValidator
from rest_framework import exceptions
from django.contrib.auth import authenticate

class UserSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(
            required=True,
            validators=[UniqueValidator(queryset=User.objects.all())]
            )
    username = serializers.CharField(
            validators=[UniqueValidator(queryset=User.objects.all())]
            )
    class Meta:
        model=User
        fields=('email','username','password')

class RoleSerializer(serializers.ModelSerializer):

    user = UserSerializer(required=True)

    class Meta:
        model = UserRole
        fields = ('user', 'user_role')

    def create(self, validated_data):
        if len(validated_data['user']['password'])>=8:
            user_data = validated_data.pop('user')
            user = UserSerializer.create(UserSerializer(), validated_data=user_data)
            user.set_password(user_data['password'])
            user.save()
            sys_user, created = UserRole.objects.update_or_create(user=user)
            return sys_user
        else :
            raise exceptions.ValidationError("ensure that password length is 8 character")

class LoginSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField()

    def validate(self, data):
        username = data.get("username", "")
        password = data.get("password", "")

        if username and password:
            user = authenticate(username=username, password=password)
            if user:
                if user.is_active:
                    data["user"] = user
                else:
                    msg = "User is deactivated."
                    raise exceptions.ValidationError(msg)
            else:
                msg = "Unable to login with given credentials."
                raise exceptions.ValidationError(msg)
        else:
            msg = "Must provide username and password both."
            raise exceptions.ValidationError(msg)
        return data
