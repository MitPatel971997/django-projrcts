from django.urls import path
from . import views

urlpatterns = [
    path('api/users', views.UserCreate.as_view(), name='account-create'),
    path('api/users-login', views.LoginView.as_view(), name='account-login'),
    path('api/users-logout', views.LogoutView.as_view(), name='account-logout'),
]
