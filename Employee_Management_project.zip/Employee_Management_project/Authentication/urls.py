from django.urls import path,include
from . import views

urlpatterns = [
    path('api/users_create', views.UserCreate.as_view(), name='account-create'),
    path('api/users_login', views.LoginView.as_view(), name='account-login'),
    path('api/users_logout', views.LogoutView.as_view(), name='account-logout'),
    #path('api/password_reset/', include('django_rest_passwordreset.urls', namespace='password_reset')),
]
