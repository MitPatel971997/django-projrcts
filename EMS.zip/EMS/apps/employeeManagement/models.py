from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class EmployeeInfo(models.Model):
    user=models.OneToOneField(User,on_delete='')#important object for inbuilt use
    salary=models.DecimalField(max_digits=6, decimal_places=2)
    address=models.CharField(max_length=150,blank=True)
    profile_pic=models.ImageField(upload_to='profile_pic',blank=True)

    def __str__(self):
        return self.user.username
