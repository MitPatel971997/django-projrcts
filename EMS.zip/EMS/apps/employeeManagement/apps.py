from django.apps import AppConfig


class EmployeemanagementConfig(AppConfig):
    name = 'employeeManagement'
