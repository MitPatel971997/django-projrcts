from django import forms
from django.contrib.auth.models import User
from apps.employeeManagement.models import EmployeeInfo


class EMployeeForm(forms.ModelForm):
    password=forms.CharField(widget=forms.PasswordInput())
    class Meta():
        model=User
        fields=('username','first_name','last_name','email','password')

class EmployeeProfileInfo(forms.ModelForm):
    class Meta():
        model=EmployeeInfo
        fields=('salary','address','profile_pic')
"""
from django.core import validators

def check_null(value):
    if(value[0].lower()=='h'):
        raise forms.ValidationError("* must required")

class Forname(forms.Form):
    fname=forms.CharField()
    lname=forms.CharField(validators=[check_null])
    email=forms.EmailField(validators=[check_null])
    contact=forms.CharField(validators=[check_null])
    password=forms.CharField(validators=[check_null])
    desigtion=forms.CharField(validators=[check_null])
    address=forms.CharField(widget=forms.Textarea,validators=[check_null])
    image=forms.ImageField()
"""
