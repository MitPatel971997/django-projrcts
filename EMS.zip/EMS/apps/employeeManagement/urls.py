from django.urls import path
from apps.employeeManagement import views
urlpatterns=[
        path(r'register/',views.register,name="register"),
        path(r'index/',views.index,name="index"),
        path(r'user_login',views.user_login,name="user_login"),

]
