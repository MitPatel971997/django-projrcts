from django.shortcuts import render
from django.http import HttpResponse
from apps.employeeManagement.forms import EMployeeForm,EmployeeProfileInfo
from django.urls import reverse
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseRedirect, HttpResponse
from django.contrib.auth import authenticate,login,logout
"""
# Create your views here.
def demo(request):
    form=forms.Forname()
    if request.method=='POST':
        form=forms.Forname(request.POST)
        if form.is_valid():
            print("hello")
    return render(request,"form_page.html",{'form':form})
"""
def index(request):
    return render(request,"index.html")

@login_required
def user_logut(request):
    logout(request)
    return HttpResponseRedirect(reverse('index'))

@login_required
def special(request):
    return HttpResponseRedirect("You logged in!!!!")

def register(request):
    registered=False
    if request.method=='POST':
        employee_form=EMployeeForm(data=request.POST)
        employee_info=EmployeeProfileInfo(data=request.POST)

        if employee_form.is_valid() and employee_info.is_valid():
            emp=employee_form.save()
            emp.set_password(emp.password)
            emp.save()
            empinfo=employee_info.save(commit=False)
            empinfo.user=emp

            if 'profile_pic' in request.FILES:
                empinfo.profile_pic=request.FILES['profile_pic']
            empinfo.save()
            registered=True
        else:
            print(employee_form.errors,employee_info.errors)
    else:
        employee_form=EMployeeForm()
        employee_info=EmployeeProfileInfo()

    return render(request,"registration.html",{'employee_form':employee_form,'employee_info':employee_info,'registered':registered })

def user_login(request):
    if request.method=="POST":
        username=request.POST.get('username')
        password=request.POST.get('password')

        user=authenticate(username=username,password=password)
        if user:
            if user.is_active:
                login(request,user)
                return HttpResponseRedirect(reverse('index'))
            else:
                return HttpResponseRedirect("Not Active")
        else:
            print("login failed")
            return HttpResponseRedirect("inalid")
    else:
        return render(request,"login.html")
