from django.contrib import admin
from apps.employeeManagement.models import EmployeeInfo


# Register your models here.
admin.site.register(EmployeeInfo)
